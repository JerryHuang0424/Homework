#include <iostream>
#include <vector>

using namespace std;

bool is_prime(int n) {
    if (n <= 1) return false;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return false;
    }
    return true;
}

bool is_palindrome(int n) {
    int reversed = 0;
    int original = n;
    while (n > 0) {
        reversed = reversed * 10 + n % 10;
        n /= 10;
    }
    return original == reversed;
}

int main() {
    vector<int> palindromic_primes;
    int count = 0;
    int number = 2;
    while (count < 100) {
        if (is_prime(number) && is_palindrome(number)) {
            palindromic_primes.push_back(number);
            count++;
        }
        number++;
    }
    for (int i = 0; i < palindromic_primes.size(); i++) {
        cout << palindromic_primes[i];
        if ((i + 1) % 10 == 0) {
            cout << endl;
        } else {
            cout << " ";
        }
    }
    return 0;
}
