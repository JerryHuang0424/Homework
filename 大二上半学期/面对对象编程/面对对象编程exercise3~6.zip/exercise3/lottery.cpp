// lottery.cpp
// A program to generate a lottery of a three-digit number and check the user's input

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
// Generate a lottery number
srand(time(0)); // Seed the random number generator
int lottery = rand() % 1000; // Get a random number between 0 and 999
// Prompt the user to enter a three-digit number
cout << "Enter your lottery pick (three digits): ";
int guess;
cin >> guess;

// Get digits from lottery
int lotteryDigit1 = lottery / 100; // Get the first digit
int lotteryDigit2 = (lottery / 10) % 10; // Get the second digit
int lotteryDigit3 = lottery % 10; // Get the third digit

// Get digits from guess
int guessDigit1 = guess / 100; // Get the first digit
int guessDigit2 = (guess / 10) % 10; // Get the second digit
int guessDigit3 = guess % 10; // Get the third digit

cout << "The lottery number is " << lottery << endl;

// Check the guess
if (guess == lottery) // If the user input matches the lottery number in the exact order
cout << "Exact match: you win $10,000" << endl;
else if (guessDigit1 == lotteryDigit2 && guessDigit2 == lotteryDigit3 && guessDigit3 == lotteryDigit1 || // If all digits in the user input match all digits in the lottery number
guessDigit1 == lotteryDigit3 && guessDigit2 == lotteryDigit1 && guessDigit3 == lotteryDigit2)
cout << "Match all digits: you win $3,000" << endl;
else if (guessDigit1 == lotteryDigit1 || guessDigit1 == lotteryDigit2 || guessDigit1 == lotteryDigit3 || // If one digit in the user input matches a digit in the lottery number
guessDigit2 == lotteryDigit1 || guessDigit2 == lotteryDigit2 || guessDigit2 == lotteryDigit3 ||
guessDigit3 == lotteryDigit1 || guessDigit3 == lotteryDigit2 || guessDigit3 == lotteryDigit3)
cout << "Match one digit: you win $1,000" << endl;
else // If none of the digits in the user input matches any digits in the lottery number
cout << "Sorry, no match" << endl;

return 0;
}
