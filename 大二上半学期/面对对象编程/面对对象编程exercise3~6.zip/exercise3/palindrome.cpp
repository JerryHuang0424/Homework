// palindrome.cpp
// A program that prompts the user to enter a three-digit integer and determines whether it is a palindrome number

#include <iostream>
using namespace std;

int main()
{
// Prompt the user to enter a three-digit integer
cout << "Enter a three-digit integer: ";
int number;
cin >> number;

// Get digits from the number
int digit1 = number / 100; // Get the first digit
int digit2 = (number / 10) % 10; // Get the second digit
int digit3 = number % 10; // Get the third digit

// Check if the number is a palindrome
if (digit1 == digit3) // If the first and the third digits are equal
cout << number << " is a palindrome" << endl;
else // If the first and the third digits are not equal
cout << number << " is not a palindrome" << endl;

return 0;
}