#include <iostream>
using namespace std;

int main() {
    int count = 0;

    for (int number = 2; number <= 100; number++) {
        bool isPrime = true;

        for (int divisor = 2; divisor < number; divisor++) {
            if (number % divisor == 0) {
                isPrime = false;
                break;
            }
        }

        if (isPrime) {
            cout << number << " ";
            count++;

            if (count % 5 == 0) {
                cout << endl;
            }
        }
    }

    return 0;
}
