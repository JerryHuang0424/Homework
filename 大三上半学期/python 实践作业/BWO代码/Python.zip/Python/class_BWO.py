import numpy as np
from matplotlib import pyplot as plt
import math
import random
import copy
import benchmarks
import BWO
class BWO_CLASS:
    def __init__(self, population_size=300, max_iterations=500, objective_function="F9"):
        # 初始化 BWO 类。
        #
        # 参数：
        # population_size (int): 种群数量，默认为 300。
        # max_iterations (int): 最大迭代次数，默认为 500。
        # objective_function (callable): 目标函数，默认为 F9函数。

        self.population_size = population_size
        self.max_iterations = max_iterations
        self.objective_function = objective_function

    def BWO_function(self):
        func_details1 = benchmarks.getFunctionSet(self.objective_function)
        lb = func_details1[1]
        ub = func_details1[2]
        dim = func_details1[3]
        fobj = getattr(benchmarks, self.objective_function)  # 获取函数求解
        print(str(self.objective_function) + " " +
              str(self.max_iterations) + " " +
              str(self.population_size) + " " +
              str(ub) + " " +
              str(lb) + " " +
              str(dim) + " " +
              str(fobj))


class BWO_solution(BWO_CLASS):
    def BWO_function(self):
        func_details1 = benchmarks.getFunctionSet(self.objective_function)
        lb = func_details1[1]
        ub = func_details1[2]
        dim = func_details1[3]
        fobj = getattr(benchmarks, self.objective_function)  # 获取函数求解
        x = BWO.BWO(fobj, lb, ub, dim, self.population_size, self.max_iterations)


if __name__ == '__main__':
    bwo_test = BWO_CLASS()
    bwo_test.BWO_function()


    bwo = BWO_solution()
    bwo.BWO_function()
